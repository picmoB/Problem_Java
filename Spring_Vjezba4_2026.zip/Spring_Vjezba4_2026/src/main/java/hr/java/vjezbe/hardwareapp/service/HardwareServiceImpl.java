package hr.java.vjezbe.hardwareapp.service;

import hr.java.vjezbe.hardwareapp.domain.Hardware;
import hr.java.vjezbe.hardwareapp.dto.HardwareDTO;
import hr.java.vjezbe.hardwareapp.repository.SpringDataHardwareRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HardwareServiceImpl implements HardwareService{

    private SpringDataHardwareRepository springDataHardwareRepository;

    /*
    public HardwareServiceImpl(HardwareRepository hardwareRepository) {
        this.hardwareRepository = hardwareRepository;
    }
     */

    @Override
    public List<HardwareDTO> findAll() {
        /*return hardwareRepository.findAll().stream().map(HardwareDTO::new).collect(Collectors.toList());*/
        return springDataHardwareRepository.findAll()
                .stream()
                .map(HardwareDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<HardwareDTO> findByCode(String code) {
        return springDataHardwareRepository.findByCode(code).stream()
                .map(this::convertArticleToArticleDTO).findFirst();
    }

    @Override
    public Optional<HardwareDTO> save(HardwareDTO hardwareDTO) {
        return Optional.of(convertArticleToArticleDTO(springDataHardwareRepository.save(convertArticleDtoToArticle(hardwareDTO))));
    }

    @Override
    public Optional<HardwareDTO> update(String code, HardwareDTO updatedHardwareDTO) {
        return Optional.empty();
    }

    @Override
    public Optional<HardwareDTO> update(HardwareDTO hardwareDTO, Integer id) {
        Optional<Hardware> hardwareUpdate = springDataHardwareRepository.findById(id);

        if (hardwareUpdate.isPresent()) {
            Hardware hardware = convertArticleDtoToArticle(hardwareDTO);
            springDataHardwareRepository.save(hardware);
            return Optional.of(convertArticleToArticleDTO(hardware));
        }

        return Optional.empty();
    }

    @Override
    public void deleteByCode(String code) {
        springDataHardwareRepository.delete(code);
    }

    private HardwareDTO convertArticleToArticleDTO(Hardware hardware) {
        return new HardwareDTO(hardware.getName(),
                hardware.getType(), hardware.getCode(), hardware.getPrice());
    }

    private Hardware convertArticleDtoToArticle(HardwareDTO hardwareDTO) {
        Long latestId =
                springDataHardwareRepository.findAll().stream()
                        .max((a1, a2) -> a1.getId().compareTo(a2.getId()))
                        .get().getId();

        return new Hardware(latestId + 1, hardwareDTO.getName(),
                hardwareDTO.getType(), hardwareDTO.getCode(),
                hardwareDTO.getPrice());
    }
}
