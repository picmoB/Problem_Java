package hr.java.vjezbe.hardwareapp.domain;

import hr.java.vjezbe.hardwareapp.dto.HardwareDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "type")
public enum Type {
    CPU, GPU, MBO, RAM, STORAGE, OTHER;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "typeHardware")
    @JoinColumn(name = "hardware_id")
    private Set<Hardware> hardwares = new HashSet<Hardware>();
}
