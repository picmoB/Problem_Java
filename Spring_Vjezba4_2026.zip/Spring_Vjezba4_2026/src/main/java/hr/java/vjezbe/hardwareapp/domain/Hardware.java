package hr.java.vjezbe.hardwareapp.domain;

import hr.java.vjezbe.hardwareapp.dto.HardwareDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hardware")
public class Hardware {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String code;
    private String name;
    private Type type;
    private long stock;
    private BigDecimal price;

    public Hardware(long id, String name, Type type, String code, long stock, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.code = code;
        this.stock = stock;
        this.price = price;
    }

    public Hardware(HardwareDTO hardwareDTO) {
        this.name = hardwareDTO.getName();
        this.type = hardwareDTO.getType();
        this.code = hardwareDTO.getCode();
        this.stock = hardwareDTO.getStock();
        this.price = hardwareDTO.getPrice();
    }

    @ManyToOne
    private Type typeHardware;

    public Hardware(long l, @NotBlank(message = "Name must not be empty") @Size(max = 200, message = "Name can't have more than 200 characters") String name, @NotNull(message = "Type must be set to CPU, GPU, MBO, RAM, STORAGE or OTHER") Type type, @NotBlank(message = "Code must not be empty") @Size(min = 7, max = 7, message = "Code must have 7 characters") String code, @PositiveOrZero(message = "Price must be positive or zero") @Digits(integer = 5, fraction = 2, message = "Price can't be higher than 99999") BigDecimal price) {
        this.id = l;
        this.name = name;
        this.type = type;
        this.code = code;
        this.stock = stock;
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hardware hardware = (Hardware) o;
        return stock == hardware.stock && Objects.equals(name, hardware.name) && type == hardware.type && Objects.equals(code, hardware.code) && Objects.equals(price, hardware.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, type, code, stock, price);
    }
}
